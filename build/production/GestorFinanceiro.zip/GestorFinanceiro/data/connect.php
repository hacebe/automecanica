<?php
session_start();

$mysqli = new Mysqli('localhost', 'root', '923885', 'cacp_gestor');
$empresaId = 1;

/*$res = $mysqli->query("SELECT * FROM usuarios") or die($mysqli->error);
while($r = $res->fetch_assoc()){
	print_r($r);
}*/