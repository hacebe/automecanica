<?php
include "connect.php";

if(isset($_GET['module'])) {

	$module = $_GET['module'];

	switch($module){		
		case "salvar":

			$id = $_POST['id'];			
			$nome = $_POST['nome'];
			$sistema = $_POST['sistema'];
			$contabil = $_POST['contabil'];			

			if($id == ""){	
				$result = $mysqli->query("
					INSERT 
					INTO 
					favorecidos 
					(`nome`, `sistema`, `contabil` ,`tipo`, `empresa_id`) 
					VALUES 
					('". $nome ."','". $sistema ."','". $contabil ."','C', '$empresaId')
				");
			}else{
				$result = $mysqli->query("
					UPDATE 
					favorecidos 
					SET `nome` = '". $nome ."', `sistema` = '". $sistema ."', `contabil`='". $contabil ."' 
					WHERE 
					`id` = '". $id ."'
				");
			}

			
			echo json_encode(
				array(
					"success" => empty($mysqli->error),
					"error" => $mysqli->error					
				)
			);
			
		break;
		case "getClientes":
			$result = $mysqli->query("			
				SELECT 
				*
				FROM 
				favorecidos 
				WHERE 
				tipo = 'C'
				AND
				empresa_id = '$empresaId'");
			
			
			$data = array();

			while ($row = $result->fetch_assoc()) {

			    $data[] = $row;

			}
			
			echo json_encode(
				array(
					"success" => empty($mysqli->error),
					"error" => $mysqli->error,
					"data" => $data
				)
			);

		break;
		case "delete":
			$id = $_POST['id'];

			$result = $mysqli->query("			
				DELETE
				FROM 
				favorecidos 
				WHERE 
				id = '". $id ."'
			");		
			
			echo json_encode(
				array(
					"success" => empty($mysqli->error),
					"error" => $mysqli->error,
					"excluido" => $mysqli->affected_rows
				)
			);

		break;
	}

}else{
	die("<center><h1>Forbidden</h1></center>");
}
