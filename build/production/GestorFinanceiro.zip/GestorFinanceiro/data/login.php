<?php
header("Access-Control-Allow-Origin: *");
include "connect.php";
if(isset($_POST['usuario']) && isset($_POST['senha'])){

	$usuario = $_POST['usuario'];
	$senha = $_POST['senha'];

	$result = $mysqli->query("
		SELECT 
		*
		FROM 
		cacp_gestor.usuarios
		WHERE 
		usuario = '" . $mysqli->real_escape_string($usuario) . "' 
		and
		senha = '". $senha . "'
		") or die($mysqli->error);

	if($result->num_rows){

		$r = $result->fetch_assoc();

		$_SESSION['userhash'] = $r['hash'];
		$_SESSION['username'] = $r['nome'];

		echo json_encode(
			array(
				"success" => empty($mysqli->error),
				"error" => $mysqli->error,
				"logado" => 1,
				"nome" => $r['nome']
			)
		);
	}else{

		echo json_encode(
			array(
				"success" => 0,
				"error" => "Usuario ou senha incorreta!",
				"logado" => 0
				)
			);

	}

}else{
	echo json_encode(
		array(
			"success" => 0,
			"error" => "Usuario ou senha nao informados!",
			"logado" => 0
			)
		);
}
?>