<?php
include "connect.php";

function mask($val, $mask)
{
  	$maskared = '';
	$k = 0;
	for($i = 0; $i<=strlen($mask)-1; $i++)
	{
		if($mask[$i] == '#')
		{
			if(isset($val[$k]))
			$maskared .= $val[$k++];
		}
		else
		{
			if(isset($mask[$i]))
			$maskared .= $mask[$i];
		}
	}
	return $maskared;
}

function createTree($node, $arr)
{
	/** Creates a tree containing  its children nodes  **/
	//echo sizeof($arr);
	for ($i=0; $i < sizeof($arr); $i++) { 
		
		if($arr[$i]['parent'] == $node->id){			

			$newNode = new stdClass();
			$newNode->id = $arr[$i]['id'];
			$newNode->parent = $arr[$i]['parent'];
			$newNode->textNoMask = $arr[$i]['nome'];
			$newNode->text = $arr[$i]['mask'] . " - " . $arr[$i]['nome'];
			//$newNode->leaf = false;
			$newNode->mask = $arr[$i]['mask'];
			$newNode->contacontabil = $arr[$i]['contacontabil'];
			$newNode->inativo = $arr[$i]['inativo'];
			$newNode->tipo = $arr[$i]['tipo'];
			
			$newNode->children = array();			
			$node->children[] = $newNode;
			createTree($newNode, $arr);

		}
	}	

}
if(isset($_GET['module'])) {
	$module = $_GET['module'];
	switch($module){
		case "getAll":
			$result = $mysqli->query("SELECT cod as id, parent, mask, nome, tipo, contacontabil, inativo FROM plano_contas_tmp") or die($mysqli->error) ;
			$arr = array();
			while($r = $result->fetch_assoc()){
				if($r['parent'] == null) $r['parent'] = 0;
				array_push($arr, $r);
				//echo $r['id'] . "\t\t" . $r['parent'] . "\t\t" . $r['mask'] . "\t" . $r['nome'] . "\n";
			}
			$node = new stdClass();
			$node->text = "Root";
			$node->expanded = true;
			$node->children = array();

			createTree($node, $arr);



			//print_r(clearEmptyChildren($node));
			//print_r($node);

			$output = json_encode(
				array(
					"success" => empty($mysqli->error),
					"error" => $mysqli->error,
					"children" => $node->children
				)
			);
			//$output = str_replace(",\"children\":[]", ",\"leaf\": true", $output);
			$output = str_replace(",\"children\":[]", ",\"children\":[],\"leaf\": true", $output);
			$output = str_replace(",\"children\":[", ",\"expanded\": true,\"children\":[", $output);
			echo $output;
			//print_r($arr);
		break;
		case "salvar":
			$parent = $_POST['parent'];
			$classificacao = $_POST['id'];
			$mask = str_replace("..", "", mask($classificacao, "#.#.#.##.###.###"));
			if($mask[strlen($mask)-1] == '.') $mask = substr($mask, 0, strlen($mask)-1);

			$descricao = $_POST['textNoMask'];
			$contacontabil = $_POST['contacontabil'];
			$tipo = $_POST['tipo'];
			$inativo = $_POST['inativo'];

			$mode = $_POST['mode'];

			if($mode == 'N'){
				$result = $mysqli->query("SELECT * FROM plano_contas_tmp WHERE empresa_id = '$empresaId' and cod = '$classificacao'") or die($mysqli->error());

				if(!$result->num_rows){
					$query = "
						INSERT INTO plano_contas_tmp
						(empresa_id, mask, cod, parent, nome, tipo, contacontabil, inativo)
						VALUES
						('$empresaId', '" . $mask ."', $classificacao, $parent, '$descricao', '$tipo', '$contacontabil', '$inativo')";				

					$mysqli->query($query) or die($mysqli->error);
					
				}else{
					echo json_encode(
						array(
							"success" => false,
							"error" => "Classificacao ja existente!"
						)					
					);
					exit;
				}
			}else if($mode == 'E'){
				$query = "
					UPDATE plano_contas_tmp
					SET 
					nome='$descricao', tipo='$tipo', contacontabil='$contacontabil', inativo='$inativo'
					WHERE 
					cod = '$classificacao'";				

				//echo $query;

				$mysqli->query($query) or die($mysqli->error);
			}

			echo json_encode(
				array(
					"success" => empty($mysqli->error),
					"error" => $mysqli->error
				)
			);



			//$result = $mysqli->query("");
		break;
	}
}

?>