<?php
session_start();
require_once("autoload.php");

function bind_array($stmt, &$row) {
    $md = $stmt->result_metadata();
    $params = array();
    while($field = $md->fetch_field()) {
        $params[] = &$row[$field->name];
    }

    call_user_func_array(array($stmt, 'bind_result'), $params);
}

if(isset($_GET['module'])) {

	$module = $_GET['module'];

	$userhash = (isset($_SESSION['userhash'])) ? $_SESSION['userhash'] : "  ";

	$mysqli = new Mysqli('localhost', 'root', '102030', 'cacp_gestor');

	switch($module){
		case "login":

			if(isset($_POST['usuario']) && isset($_POST['senha'])){

				$usuario = $_POST['usuario'];
				$senha = md5($_POST['senha']);

				$result = $mysqli->query("
					SELECT 
					*
					FROM 
					cacp_gestor.usuarios
					WHERE 
					usuario = '" . $mysqli->real_escape_string($usuario) . "' 
					and
					senha = '". $senha . "'
					") or die($mysqli->error);

				if($result->num_rows){

					$r = $result->fetch_assoc();

					$_SESSION['userhash'] = $r['hash'];

					echo json_encode(
						array(
							"success" => empty($mysqli->error),
							"error" => $mysqli->error,
							"logado" => 1
						)
					);
				}else{

					echo json_encode(
						array(
							"success" => 0,
							"error" => "Usuario ou senha incorreta!",
							"logado" => 0
						)
					);

				}
				
			}else{
				echo json_encode(
					array(
						"success" => 0,
						"error" => "Usuario ou senha nao informados!",
						"logado" => 0
					)
				);
			}

		break;

		case "getEmpresas":
			$result = $mysqli->query("			
				SELECT 
				e.id, e.razao_social, e.nome_fantasia, e.cnpj, e.endereco, e.telefone 
				FROM 
				cacp_gestor.usuario_empresa as ue, 
				cacp_gestor.usuarios as u, 
				cacp_gestor.empresas as e 
				WHERE 
				u.hash = '" . $userhash . "' 
				and 
				e.id = ue.empresa_id
				and
				u.id = ue.usuario_id;");		
			
			
			$data = array();

			while ($row = $result->fetch_assoc()) {

			    $data[] = $row;

			}
			
			echo json_encode(
				array(
					"success" => empty($mysqli->error),
					"error" => $mysqli->error,
					"data" => $data
				)
			);

		break;
	}

}else{
	die("<center><h1>Forbidden</h1></center>");
}
